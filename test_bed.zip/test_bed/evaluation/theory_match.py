# evaluation/theory_match.py

import torch
from theory.gaussian_predictions import (
    predicted_A_conditional,
    predicted_A_joint,
    predicted_A_quadratic_u,
    predicted_A_quadratic_v,
)


@torch.no_grad()
def theory_match_error(model, modality, target):
    """Relative Frobenius error between the learned cross-term and A*.

    Compares the learned cross-term against the analytical optimum A* for the
    loss/tilting that was actually trained.  Returns None when the paper gives
    no closed form (two-sided L2, L2 joint).

    Parameters
    ----------
    model    : LinearCLIP
    modality : PairSampler with C_uu / C_vv / C_uv implemented
    target   : 'cosine_conditional' (Thm 5.1) | 'cosine_joint' (Thm 5.6)
             | 'quadratic_u' / 'quadratic_v' (Thm 5.3) | 'mse' (K) | 'none'

    Returns
    -------
    scalar tensor  ||A_learned - A*|| / ||A*||,  or None.
    """
    if target == 'none':
        return None

    device = next(model.parameters()).device
    C_uu = modality.C_uu().double().to(device)
    C_vv = modality.C_vv().double().to(device)
    C_uv = modality.C_uv().double().to(device)

    if target == 'mse':
        # MSE trains the RAW map W_u^T W_v -> K = C_uu^-1 C_uv (no logit_scale),
        # so compare the unscaled weights, not cross_term().
        A_star = torch.linalg.solve(C_uu, C_uv)
        A_learned = (model.u_encoder.weight.T @ model.v_encoder.weight).double()
    else:
        if target == 'cosine_conditional':
            A_star = predicted_A_conditional(C_uu, C_uv, C_vv)   # Thm 5.1
        elif target == 'cosine_joint':
            A_star = predicted_A_joint(C_uu, C_uv, C_vv)         # Thm 5.6
        elif target == 'quadratic_v':
            A_star = predicted_A_quadratic_v(C_uu, C_uv, C_vv)   # Thm 5.3 (v|u)
        elif target == 'quadratic_u':
            A_star = predicted_A_quadratic_u(C_uu, C_uv, C_vv)   # Thm 5.3 (u|v)
        else:
            raise ValueError(f"Unknown theory target: {target!r}")
        A_learned = model.cross_term().double()

    return torch.norm(A_learned - A_star, p='fro') / torch.norm(A_star, p='fro')
